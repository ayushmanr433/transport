export const Footer = () => {
  return (
    <div className="bg-dark text-light p-3">
      <h1 className="text-center">All Right Reserved @Ayushmaan</h1>
    </div>
  );
};
