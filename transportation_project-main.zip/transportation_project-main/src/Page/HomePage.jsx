import { Layout } from "../Component/Layout/Layout"

export const Home = () => {
    return (
        <Layout>
            <h1>HomePage</h1>
        </Layout>
    )
}